import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { accountAPI, integrationAPI } from '@/lib/api';
import { Link2, CheckCircle, XCircle, RefreshCw, AlertCircle } from 'lucide-react';

export default function IntegrationPage() {
  const queryClient = useQueryClient();
  const [syncing, setSyncing] = useState<string | null>(null);

  const { data: accountsData, isLoading } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => accountAPI.getAccounts(),
  });

  const accounts = accountsData?.data?.accounts || [];

  // 동기화 mutation
  const syncMutation = useMutation({
    mutationFn: async (platform: string) => {
      setSyncing(platform);
      // 캠페인과 메트릭 동시 동기화
      await integrationAPI.syncAll(platform);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['accounts'] });
      queryClient.invalidateQueries({ queryKey: ['campaigns'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-summary'] });
      alert('동기화가 완료되었습니다!');
    },
    onError: (error: any) => {
      alert(error.response?.data?.message || '동기화에 실패했습니다.');
    },
    onSettled: () => {
      setSyncing(null);
    },
  });

  const handleConnect = async (platform: string) => {
    try {
      const response = await integrationAPI.getAuthUrl(platform);
      const authUrl = response.data.authUrl;
      
      // OAuth 인증 페이지로 이동
      window.location.href = authUrl;
    } catch (error: any) {
      alert(error.response?.data?.message || '연동에 실패했습니다.');
    }
  };

  const handleSync = (platform: string) => {
    syncMutation.mutate(platform);
  };

  const platforms = [
    {
      id: 'google',
      name: 'Google Ads',
      description: 'Google 검색, 디스플레이, YouTube 광고',
      icon: '🔍',
      color: 'from-red-500 to-yellow-500',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200',
    },
    {
      id: 'meta',
      name: 'Meta Ads',
      description: 'Facebook, Instagram 광고',
      icon: '📘',
      color: 'from-blue-500 to-blue-700',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
    },
    {
      id: 'naver',
      name: 'Naver Ads',
      description: '네이버 검색광고, 디스플레이 광고',
      icon: '🟢',
      color: 'from-green-500 to-green-700',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
    },
  ];

  const getAccountForPlatform = (platform: string) => {
    return accounts.find((acc: any) => acc.platform === platform);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">광고 플랫폼 연동</h1>
        <p className="text-gray-600 mt-1">
          Google, Meta, Naver 광고 계정을 연동하여 통합 관리하세요
        </p>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start">
        <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
        <div className="text-sm text-blue-800">
          <p className="font-medium mb-1">안전한 OAuth 2.0 인증</p>
          <p>각 플랫폼의 공식 OAuth 인증을 사용하여 안전하게 계정을 연동합니다. 비밀번호는 저장되지 않습니다.</p>
        </div>
      </div>

      {/* Platform Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {platforms.map((platform) => {
          const account = getAccountForPlatform(platform.id);
          const isConnected = !!account;
          const isSyncing = syncing === platform.id;

          return (
            <div
              key={platform.id}
              className={`bg-white rounded-xl shadow-sm border ${platform.borderColor} overflow-hidden transition hover:shadow-md`}
            >
              {/* Header */}
              <div className={`${platform.bgColor} p-6 border-b ${platform.borderColor}`}>
                <div className="flex items-center justify-between mb-4">
                  <div className={`text-4xl w-16 h-16 flex items-center justify-center bg-gradient-to-br ${platform.color} rounded-xl`}>
                    <span className="text-white text-2xl">{platform.icon}</span>
                  </div>
                  {isConnected ? (
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  ) : (
                    <XCircle className="w-6 h-6 text-gray-400" />
                  )}
                </div>
                <h3 className="text-xl font-bold text-gray-900">{platform.name}</h3>
                <p className="text-sm text-gray-600 mt-1">{platform.description}</p>
              </div>

              {/* Body */}
              <div className="p-6 space-y-4">
                {isConnected ? (
                  <>
                    {/* Account Info */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">계정 ID</span>
                        <span className="font-medium text-gray-900">{account.account_id}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">계정명</span>
                        <span className="font-medium text-gray-900">{account.account_name}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">연동일</span>
                        <span className="font-medium text-gray-900">
                          {new Date(account.created_at).toLocaleDateString('ko-KR')}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">마지막 동기화</span>
                        <span className="font-medium text-gray-900">
                          {account.last_sync_at
                            ? new Date(account.last_sync_at).toLocaleString('ko-KR')
                            : '동기화 안됨'}
                        </span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2 pt-2">
                      <button
                        onClick={() => handleSync(platform.id)}
                        disabled={isSyncing}
                        className="flex-1 flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {isSyncing ? (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                            동기화 중...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2" />
                            동기화
                          </>
                        )}
                      </button>
                      <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                        연동 해제
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Not Connected */}
                    <div className="text-center py-4">
                      <p className="text-sm text-gray-600 mb-4">
                        {platform.name} 계정을 연동하여<br />
                        캠페인과 데이터를 가져오세요
                      </p>
                      <button
                        onClick={() => handleConnect(platform.id)}
                        className={`w-full flex items-center justify-center px-4 py-3 bg-gradient-to-r ${platform.color} text-white rounded-lg hover:shadow-lg transition font-medium`}
                      >
                        <Link2 className="w-5 h-5 mr-2" />
                        {platform.name} 연동하기
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Connected Accounts Summary */}
      {accounts.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">연동된 계정</h2>
          <div className="space-y-3">
            {accounts.map((account: any) => (
              <div
                key={account.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                    <span className="text-xl">
                      {account.platform === 'google' ? '🔍' : account.platform === 'meta' ? '📘' : '🟢'}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{account.account_name}</p>
                    <p className="text-sm text-gray-600 capitalize">{account.platform}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-green-600 font-medium">연동됨</span>
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
