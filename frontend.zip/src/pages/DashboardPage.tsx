import { useQuery } from '@tanstack/react-query';
import { dashboardAPI } from '@/lib/api';
import { formatCurrency, formatNumber, formatPercent } from '@/lib/utils';
import { TrendingUp, MousePointerClick, DollarSign, Target, ArrowUp, ArrowDown } from 'lucide-react';

export default function DashboardPage() {
  const { data: summary, isLoading } = useQuery({
    queryKey: ['dashboard-summary'],
    queryFn: () => dashboardAPI.getSummary(),
  });

  const { data: performance } = useQuery({
    queryKey: ['channel-performance'],
    queryFn: () => dashboardAPI.getChannelPerformance(),
  });

  const metrics = summary?.data?.metrics;
  const budget = summary?.data?.budget;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">통합 성과 대시보드</h1>
          <p className="text-gray-600 mt-1">실시간 마케팅 성과를 한눈에 확인하세요</p>
        </div>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
          리포트 다운로드
        </button>
      </div>

      {/* Main Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="총 노출수"
          value={formatNumber(metrics?.impressions || 0)}
          change={12.5}
          icon={TrendingUp}
          color="blue"
        />
        <MetricCard
          title="총 클릭수"
          value={formatNumber(metrics?.clicks || 0)}
          change={8.2}
          icon={MousePointerClick}
          color="green"
        />
        <MetricCard
          title="총 광고비"
          value={formatCurrency(metrics?.cost || 0)}
          change={-3.1}
          icon={DollarSign}
          color="yellow"
        />
        <MetricCard
          title="전환수"
          value={formatNumber(metrics?.conversions || 0)}
          change={15.8}
          icon={Target}
          color="purple"
        />
      </div>

      {/* Performance Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-sm font-medium text-gray-500 mb-2">이 광고를 평균 얼마나 클릭했나요?</h3>
          <p className="text-2xl font-bold text-gray-900">{formatPercent(metrics?.ctr || 0)}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-sm font-medium text-gray-500 mb-2">광고 클릭당 비용(단가) 평균은 얼마인가요?</h3>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(metrics?.cpc || 0)}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-sm font-medium text-gray-500 mb-2">광고 투자수익률(ROAS)은 얼마인가요?</h3>
          <p className="text-2xl font-bold text-gray-900">{(metrics?.roas || 0).toFixed(2)}x</p>
        </div>
      </div>

      {/* Channel Performance */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-900">채널별 성과</h2>
          <p className="text-sm text-gray-600 mt-1">각 광고 플랫폼의 실시간 성과를 확인하세요</p>
        </div>
        <div className="p-6">
          <div className="space-y-6">
            {performance?.data?.performance?.map((channel: any) => (
              <div key={channel.platform} className="border-b border-gray-100 pb-6 last:border-0 last:pb-0">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getPlatformBgColor(channel.platform)}`}>
                      {getPlatformIcon(channel.platform)}
                    </div>
                    <div className="ml-3">
                      <h3 className="font-semibold text-gray-900 capitalize">{channel.platform}</h3>
                      <p className="text-sm text-gray-500">{channel.campaigns}개 캠페인 진행 중</p>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">노출수</p>
                    <p className="text-lg font-semibold text-gray-900">{formatNumber(channel.metrics.impressions)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">클릭수</p>
                    <p className="text-lg font-semibold text-gray-900">{formatNumber(channel.metrics.clicks)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">CTR</p>
                    <p className="text-lg font-semibold text-gray-900">{formatPercent(channel.metrics.ctr)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">ROAS</p>
                    <p className="text-lg font-semibold text-green-600">{channel.metrics.roas.toFixed(2)}x</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Budget Overview */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-900">예산 현황</h2>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">총 예산</span>
              <span className="text-xl font-bold text-gray-900">{formatCurrency(budget?.total || 0)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">사용 예산</span>
              <span className="text-xl font-bold text-blue-600">{formatCurrency(budget?.spent || 0)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">잔여 예산</span>
              <span className="text-xl font-bold text-green-600">{formatCurrency(budget?.remaining || 0)}</span>
            </div>
            
            {/* Progress Bar */}
            <div className="pt-4">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>예산 사용률</span>
                <span className="font-medium">{formatPercent(budget?.utilizationRate || 0)}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(budget?.utilizationRate || 0, 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// MetricCard Component
interface MetricCardProps {
  title: string;
  value: string;
  change?: number;
  icon: any;
  color: 'blue' | 'green' | 'yellow' | 'purple';
}

function MetricCard({ title, value, change, icon: Icon, color }: MetricCardProps) {
  const colors = {
    blue: { bg: 'bg-blue-50', text: 'text-blue-600', border: 'border-blue-100' },
    green: { bg: 'bg-green-50', text: 'text-green-600', border: 'border-green-100' },
    yellow: { bg: 'bg-yellow-50', text: 'text-yellow-600', border: 'border-yellow-100' },
    purple: { bg: 'bg-purple-50', text: 'text-purple-600', border: 'border-purple-100' },
  };

  const isPositive = change && change > 0;

  return (
    <div className={`bg-white rounded-xl shadow-sm border ${colors[color].border} p-6 transition hover:shadow-md`}>
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${colors[color].bg}`}>
          <Icon className={`w-6 h-6 ${colors[color].text}`} />
        </div>
        {change !== undefined && (
          <div className={`flex items-center text-sm font-medium ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            {isPositive ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
            {Math.abs(change)}%
          </div>
        )}
      </div>
      <p className="text-sm text-gray-600 mb-1">{title}</p>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  );
}

// Helper functions
function getPlatformBgColor(platform: string) {
  const colors: Record<string, string> = {
    google: 'bg-red-50',
    meta: 'bg-blue-50',
    naver: 'bg-green-50',
  };
  return colors[platform.toLowerCase()] || 'bg-gray-50';
}

function getPlatformIcon(platform: string) {
  const iconClass = "w-5 h-5 font-bold";
  const colors: Record<string, string> = {
    google: 'text-red-600',
    meta: 'text-blue-600',
    naver: 'text-green-600',
  };
  const color = colors[platform.toLowerCase()] || 'text-gray-600';
  
  return <span className={`${iconClass} ${color}`}>{platform[0].toUpperCase()}</span>;
}
