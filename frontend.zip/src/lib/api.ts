import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api/v1';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor - 토큰 자동 추가
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor - 에러 처리
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // 인증 실패 시 로그인 페이지로 리다이렉트
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (data: { name: string; email: string; password: string; company: string }) =>
    api.post('/auth/register', data),
  
  login: (data: { email: string; password: string }) =>
    api.post('/auth/login', data),
  
  getMe: () => api.get('/auth/me'),
};

// Dashboard API
export const dashboardAPI = {
  getSummary: () => api.get('/dashboard/summary'),
  
  getChannelPerformance: (params?: { startDate?: string; endDate?: string }) =>
    api.get('/dashboard/channel-performance', { params }),
  
  getInsights: (params?: { limit?: number; priority?: string }) =>
    api.get('/dashboard/insights', { params }),
  
  getBudget: (params?: { groupBy?: 'platform' | 'campaign' }) =>
    api.get('/dashboard/budget', { params }),
};

// Campaign API
export const campaignAPI = {
  getCampaigns: (params?: { page?: number; limit?: number; platform?: string; status?: string }) =>
    api.get('/campaigns', { params }),
  
  getCampaign: (id: number) => api.get(`/campaigns/${id}`),
  
  createCampaign: (data: any) => api.post('/campaigns', data),
  
  updateCampaign: (id: number, data: any) => api.put(`/campaigns/${id}`, data),
  
  deleteCampaign: (id: number) => api.delete(`/campaigns/${id}`),
  
  getMetrics: (id: number) => api.get(`/campaigns/${id}/metrics`),
};

// Account API
export const accountAPI = {
  getAccounts: (params?: { platform?: string }) =>
    api.get('/accounts', { params }),
  
  getAccount: (id: number) => api.get(`/accounts/${id}`),
  
  createAccount: (data: any) => api.post('/accounts', data),
  
  updateAccount: (id: number, data: any) => api.put(`/accounts/${id}`, data),
  
  deleteAccount: (id: number) => api.delete(`/accounts/${id}`),
};

// Integration API
export const integrationAPI = {
  getAuthUrl: (platform: string) => api.get(`/integration/auth/${platform}`),
  
  syncCampaigns: (accountId: number) =>
    api.post(`/integration/sync/campaigns/${accountId}`),
  
  syncMetrics: (campaignId: number, data: { startDate: string; endDate: string }) =>
    api.post(`/integration/sync/metrics/${campaignId}`, data),
  
  syncAll: (data: { startDate: string; endDate: string; platform?: string }) =>
    api.post('/integration/sync/all', data),
};
